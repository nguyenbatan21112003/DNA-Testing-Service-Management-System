﻿namespace DNATestSystem.BusinessObjects.Application.Dtos.User
{
    public class UserLoginModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
