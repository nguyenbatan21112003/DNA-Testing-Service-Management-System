﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNATestSystem.BusinessObjects.Entities.Enum
{
    public enum StatusNum
    {
        Banned = -1,
        Pending = 0,
        Verified = 1
    }
}

