﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNATestSystem.BusinessObjects.Entities.Enum
{
    public enum RoleNum
    {
        Guest = 0,
        Customer = 1,
        Staff = 2,
        Manager = 3,
        Admin = 4
    }
}
